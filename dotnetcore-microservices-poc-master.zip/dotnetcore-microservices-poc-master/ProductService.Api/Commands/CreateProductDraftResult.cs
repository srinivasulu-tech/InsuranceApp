using System;

namespace ProductService.Api.Commands
{
    public class CreateProductDraftResult
    {
        public Guid ProductId { get; set; }
    }
}