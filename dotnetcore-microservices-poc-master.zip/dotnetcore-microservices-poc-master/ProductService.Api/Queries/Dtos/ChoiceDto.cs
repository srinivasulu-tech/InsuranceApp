﻿namespace ProductService.Api.Queries.Dtos
{
    public class ChoiceDto
    {
        public string Code { get; set; }
        public string Label { get; set; }
    }
}
