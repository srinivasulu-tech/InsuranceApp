<template>
    <div>
        <Home msg="Welcome to LAB Insurance Sales Portal"/>
    </div>
</template>

<script>
    import Home from '@/components/Home.vue'

    export default {
        name: 'home',
        components: {
            Home
        }
    }
</script>
