<template>
    <div>
        <Chat />
    </div>
</template>

<script>
    import Chat from '@/components/Chat.vue'

    export default {
        name: 'chat',
        components: {
            Chat
        }
    }
</script>
