<template>
    <div>
        <Chatbot />
    </div>
</template>

<script>
    import Chatbot from '@/components/Chatbot.vue'

    export default {
        name: 'chatbot',
        components: {
            Chatbot
        }
    }
</script>
