namespace ChatService
{
    public class AppSettings
    {
        public string Secret { get; set; }
        public string[] AllowedChatOrigins { get; set; }
    }
}