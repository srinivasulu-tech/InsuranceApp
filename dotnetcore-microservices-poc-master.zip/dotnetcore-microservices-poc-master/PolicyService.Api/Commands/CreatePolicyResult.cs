﻿namespace PolicyService.Api.Commands
{
    public class CreatePolicyResult
    {
        public string PolicyNumber { get; set; }
    }
}
