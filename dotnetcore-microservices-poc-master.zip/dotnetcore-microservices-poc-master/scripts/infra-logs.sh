docker-compose -f infra.yml logs --tail 500 -f 
