docker-compose -f app.yml down
