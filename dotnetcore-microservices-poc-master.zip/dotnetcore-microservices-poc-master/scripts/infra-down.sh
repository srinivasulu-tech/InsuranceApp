docker-compose -f infra.yml down
